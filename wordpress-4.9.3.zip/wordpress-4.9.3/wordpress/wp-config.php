<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'abhinavv_erp');

/** MySQL database username */
define('DB_USER', 'abhinavv_admin');

/** MySQL database password */
define('DB_PASSWORD', 'Gala735quo656!');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '!?l?vJ JqU(^5pU1NU|LM(4$bS$8:anDdje<vS2=][Xu:C0u3X`GxCLr7ib#q3.S');
define('SECURE_AUTH_KEY',  'w#^QY%%|$PC&o$;W6*nfZ,_;p,-a,LM}|K;|Yf 9Q_gwz #.Ew(SjmPR#d)BE7Z?');
define('LOGGED_IN_KEY',    'wZDv;U6~nH 72DbZ F$%0)&V$bNyiFom5Y]orZ r>b]K@1&3{-muYU*DrD4dP/#w');
define('NONCE_KEY',        '+kVv#U6X5ls$36LyTF/2RTQqugGps$Sl}xvQ^ x^qD}*U`r,04_gF]FIw[Q|}oqD');
define('AUTH_SALT',        'g,S{<2FfC!)14;#f2G1TDC;W$&jDib1$l9{]A`#pL@m3+#_9q&L`KwmT}na=S$~{');
define('SECURE_AUTH_SALT', '%6cNE8>;u#om>GuqrACp-%4gyf/Vy5@TWjsj-PTm62[e(~g*3;ebDU5u++Rtp/Jy');
define('LOGGED_IN_SALT',   'fbzQ/w@(qo|*jBg5WA<40_>jU6~eaNG5eNrc0-r;shk/D{S@+2VE^<YSlOLoRo 0');
define('NONCE_SALT',       'L?#r|}/Al5m(>9:wrU-n57JT~x7Dx+#c#r!:}:-wmatO,U)Vlecgdv6o`2}mdmsl');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
